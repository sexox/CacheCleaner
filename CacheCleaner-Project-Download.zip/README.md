# CacheCleaner 2.0
Android cache-trimming utility using Shizuku UserService.

Build with JDK 17, Android SDK 34 and Gradle 8.2 using `gradle assembleDebug`.

The app asks Android Package Manager to trim caches toward 1 GiB of free storage. Android decides what can be removed; this does not guarantee clearing every application's cache. The command runs off the UI thread and has a 30-second timeout.
