package com.example.cachecleaner;

interface ICacheCleaner {
    String clearCaches();
}
