
package com.example.cachecleaner;

interface ICacheCleaner {
    void destroy() = 16777114;
    boolean clearCache(String packageName);
}
