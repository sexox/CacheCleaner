
package com.example.cachecleaner

import android.content.pm.IPackageDataObserver
import android.os.IBinder
import kotlin.system.exitProcess

class CacheCleanerService : ICacheCleaner.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun clearCache(packageName: String): Boolean {
        return try {
            val serviceManagerClass = Class.forName("android.os.ServiceManager")
            val getServiceMethod = serviceManagerClass.getMethod("getService", String::class.java)
            val packageBinder = getServiceMethod.invoke(null, "package") as IBinder
            
            val pmClass = Class.forName("android.content.pm.IPackageManager\$Stub")
            val asInterfaceMethod = pmClass.getMethod("asInterface", IBinder::class.java)
            val packageManager = asInterfaceMethod.invoke(null, packageBinder)

            val observer = object : IPackageDataObserver.Stub() {
                override fun onRemoveCompleted(pkg: String?, succeeded: Boolean) {
                    // Cache removed callback from system
                }
            }

            val deleteMethod = packageManager.javaClass.methods.find { it.name == "deleteApplicationCacheFiles" }
            if (deleteMethod != null) {
                deleteMethod.invoke(packageManager, packageName, observer)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
