# CacheCleaner 2.0

Complete Android Studio source project for CacheCleaner.

## Build requirements
- JDK 17
- Android SDK 34
- Gradle 8.2
- Internet access during the first build to download Android/Gradle dependencies

## Build
Run `gradle assembleDebug` from the project root, or use the GitHub Actions workflow in your repository.

The debug APK is created at:
`app/build/outputs/apk/debug/app-debug.apk`

## How cleaning works
The app uses Shizuku UserService and asks Android Package Manager to run:
`pm trim-caches 1G`

This asks Android to trim caches toward a free-storage target of 1 GiB. Android decides which cache files can be removed; it does not guarantee clearing every app's cache. The call runs on a background thread and has a 30-second timeout.

## Project structure
- `app/src/main/aidl`: Shizuku Binder interface
- `app/src/main/java`: Kotlin activity and Shizuku service
- `app/src/main/res`: layout, strings, theme and launcher icon
