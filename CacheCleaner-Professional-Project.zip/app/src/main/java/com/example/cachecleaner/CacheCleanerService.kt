package com.example.cachecleaner

import android.os.RemoteException

/**
 * Runs inside the Shizuku user-service process (shell privileges after approval).
 * pm trim-caches requests Android to trim app cache; it does not erase personal files.
 */
class CacheCleanerService : ICacheCleaner.Stub() {
    @Throws(RemoteException::class)
    override fun clearAllCaches(): String {
        return try {
            val process = Runtime.getRuntime().exec(
                arrayOf("sh", "-c", "pm trim-caches 4096G")
            )
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val error = process.errorStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()

            when {
                exitCode == 0 -> "SUCCESS\n${output.trim()}".trim()
                else -> "ERROR\n${error.ifBlank { output }.trim()}\nExit code: $exitCode"
            }
        } catch (e: Exception) {
            "ERROR\n${e.message ?: "Unknown error"}"
        }
    }
}
