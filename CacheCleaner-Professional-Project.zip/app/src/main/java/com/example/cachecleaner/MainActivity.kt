package com.example.cachecleaner

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var btnClear: Button
    private lateinit var progress: ProgressBar
    private lateinit var txtStatus: TextView

    @Volatile private var cacheCleanerService: ICacheCleaner? = null
    @Volatile private var isBound = false
    private val executor = Executors.newSingleThreadExecutor()
    private val requestCode = 1001

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(packageName, CacheCleanerService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("cache_cleaner")
            .debuggable(false)
            .version(2)
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { code, result ->
            if (code == requestCode) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    showStatus("تم منح صلاحية Shizuku. جارٍ الاتصال...")
                    bindUserService()
                } else {
                    showStatus("لم يتم منح صلاحية Shizuku.")
                    btnClear.isEnabled = true
                }
            }
        }

    private val userServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            cacheCleanerService = ICacheCleaner.Stub.asInterface(service)
            isBound = cacheCleanerService != null
            runOnUiThread {
                showStatus(if (isBound) "متصل وجاهز للتنظيف" else "تعذر الاتصال بالخدمة")
                btnClear.isEnabled = true
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            cacheCleanerService = null
            isBound = false
            runOnUiThread {
                showStatus("انقطع اتصال Shizuku. أعد الاتصال.")
                btnClear.isEnabled = true
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnClear = findViewById(R.id.btnClear)
        progress = findViewById(R.id.progress)
        txtStatus = findViewById(R.id.txtStatus)

        Shizuku.addRequestPermissionResultListener(permissionResultListener)
        btnClear.setOnClickListener { prepareAndClean() }

        showStatus(
            if (Shizuku.pingBinder()) {
                "Shizuku يعمل. اضغط للتنظيف."
            } else {
                "شغّل Shizuku أولاً ثم ارجع إلى التطبيق."
            }
        )
    }

    private fun prepareAndClean() {
        if (!Shizuku.pingBinder()) {
            showStatus("Shizuku غير متصل. افتحه وشغّله أولاً.")
            return
        }

        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            btnClear.isEnabled = false
            Shizuku.requestPermission(requestCode)
            showStatus("بانتظار موافقة Shizuku...")
            return
        }

        if (!isBound || cacheCleanerService == null) {
            btnClear.isEnabled = false
            showStatus("جارٍ الاتصال بخدمة التنظيف...")
            bindUserService()
            return
        }

        startCleaning()
    }

    private fun bindUserService() {
        try {
            Shizuku.bindUserService(userServiceArgs, userServiceConnection)
        } catch (e: Exception) {
            isBound = false
            cacheCleanerService = null
            runOnUiThread {
                btnClear.isEnabled = true
                showStatus("فشل الاتصال: ${e.message ?: "خطأ غير معروف"}")
            }
        }
    }

    private fun startCleaning() {
        btnClear.isEnabled = false
        progress.visibility = View.VISIBLE
        showStatus("جارٍ طلب تنظيف الكاش من أندرويد...")

        val service = cacheCleanerService
        executor.execute {
            val result = try {
                service?.clearCaches() ?: "NO_SERVICE"
            } catch (e: Exception) {
                "ERROR:${e.javaClass.simpleName}"
            }

            runOnUiThread {
                progress.visibility = View.GONE
                btnClear.isEnabled = true

                when {
                    result == "SUCCESS" ->
                        showStatus("اكتمل طلب تنظيف الكاش بنجاح. مقدار التنظيف يحدده أندرويد.")
                    result == "TIMEOUT" ->
                        showStatus("انتهت المهلة بعد 30 ثانية. لم نتمكن من تأكيد اكتمال التنظيف.")
                    result == "NO_SERVICE" ->
                        showStatus("خدمة التنظيف غير متصلة. أعد فتح التطبيق.")
                    result.startsWith("ERROR:") ->
                        showStatus("فشل أمر التنظيف: ${result.removePrefix("ERROR:")}")
                    else ->
                        showStatus("لم ينجح أمر التنظيف. النتيجة: $result")
                }
            }
        }
    }

    private fun showStatus(message: String) {
        if (::txtStatus.isInitialized) txtStatus.text = message
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)

        if (isBound) {
            try {
                Shizuku.unbindUserService(userServiceArgs, userServiceConnection, true)
            } catch (_: Exception) {
            }
        }

        executor.shutdownNow()
        super.onDestroy()
    }
}
