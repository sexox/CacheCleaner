
package com.example.cachecleaner

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

val PrimaryPurple = Color(0xFF673AB7)
val AccentYellow = Color(0xFFFFC107)
val DarkBackground = Color(0xFF121212)
val CardBackground = Color(0xFF1E1E1E)

data class AppItem(val name: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener { requestCode, grantResult ->
            // Handle permission result if needed
        }
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                CacheCleanerApp()
            }
        }
    }
}

@Composable
fun CacheCleanerApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var shizukuStatus by remember { mutableStateOf("جاري التحقق...") }
    var shizukuConnected by remember { mutableStateOf(false) }
    var appsList by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var cleaningStatus by remember { mutableStateOf("") }
    var isCleaning by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (ShizukuManager.isShizukuAvailable()) {
            if (ShizukuManager.hasPermission()) {
                shizukuStatus = "Shizuku متاح ومصرح له"
                shizukuConnected = ShizukuManager.connectService()
                if (shizukuConnected) {
                    shizukuStatus = "متصل بخدمة التنظيف بنجاح"
                    appsList = loadApps(context.packageManager)
                } else {
                    shizukuStatus = "فشل الاتصال بخدمة التنظيف"
                }
            } else {
                shizukuStatus = "Shizuku يحتاج إلى صلاحية"
                Shizuku.requestPermission(101)
            }
        } else {
            shizukuStatus = "Shizuku غير متوفر أو غير مفعل"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = DarkBackground, surface = CardBackground, primary = PrimaryPurple, secondary = AccentYellow)) {
        Scaffold(
            topBar = {
                Surface(color = PrimaryPurple, modifier = Modifier.fillMaxWidth()) {
                    Text("CacheCleaner", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                }
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).fillMaxSize().background(DarkBackground).padding(16.dp)) {
                
                // Status Card
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("حالة الخدمة:", color = Color.Gray, fontSize = 14.sp)
                        Text(shizukuStatus, color = if(shizukuConnected) AccentYellow else Color.Red, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        
                        AnimatedVisibility(visible = isCleaning || cleaningStatus.isNotEmpty()) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Text(cleaningStatus, color = Color.White, fontSize = 14.sp)
                                if (isCleaning) {
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = AccentYellow)
                                }
                            }
                        }
                    }
                }

                Text("التطبيقات المتاحة:", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

                LazyColumn {
                    items(appsList) { app ->
                        AppCard(app = app, isCleaningGlobal = isCleaning) {
                            if (shizukuConnected && !isCleaning) {
                                coroutineScope.launch {
                                    isCleaning = true
                                    cleaningStatus = "جارٍ تنظيف كاش ${app.name}..."
                                    
                                    val success = withContext(Dispatchers.IO) {
                                        ShizukuManager.clearAppCache(app.packageName)
                                    }
                                    
                                    // Simulation of realistic wait time for observer to finish
                                    delay(1500) 
                                    
                                    if (success) {
                                        cleaningStatus = "اكتملت العملية: تم طلب التنظيف لتطبيق ${app.name} بنجاح."
                                    } else {
                                        cleaningStatus = "تعذر تنظيف الملفات، قد يمنع النظام ذلك لهذا التطبيق."
                                    }
                                    isCleaning = false
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppCard(app: AppItem, isCleaningGlobal: Boolean, onCleanClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(app.packageName, color = Color.Gray, fontSize = 12.sp)
            }
            Button(
                onClick = onCleanClick,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                enabled = !isCleaningGlobal
            ) {
                Text("تنظيف", color = Color.White)
            }
        }
    }
}

suspend fun loadApps(pm: PackageManager): List<AppItem> = withContext(Dispatchers.IO) {
    val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    apps.filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName.contains("youtube") }
        .map { AppItem(it.loadLabel(pm).toString(), it.packageName) }
        .sortedBy { it.name }
}
