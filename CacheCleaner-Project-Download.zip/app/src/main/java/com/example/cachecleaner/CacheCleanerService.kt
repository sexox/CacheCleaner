package com.example.cachecleaner

import android.os.RemoteException
import java.io.File
import java.util.concurrent.TimeUnit

// Shizuku UserService classes implement the generated AIDL Binder interface directly.
class CacheCleanerService : ICacheCleaner.Stub() {
    @Throws(RemoteException::class)
    override fun clearCaches(): String {
        var process: Process? = null
        return try {
            // Android decides which cache files can be trimmed; 1G is a target free-space threshold.
            process = ProcessBuilder("sh", "-c", "pm trim-caches 1G")
                .redirectOutput(File("/dev/null"))
                .redirectError(File("/dev/null"))
                .start()
            val finished = process.waitFor(30, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                "TIMEOUT"
            } else if (process.exitValue() == 0) {
                "SUCCESS"
            } else {
                "ERROR:${process.exitValue()}"
            }
        } catch (e: Exception) {
            process?.destroyForcibly()
            "ERROR:${e.javaClass.simpleName}"
        }
    }
}
