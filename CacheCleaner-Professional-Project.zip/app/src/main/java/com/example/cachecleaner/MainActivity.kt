package com.example.cachecleaner

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    companion object { private const val REQUEST_CODE = 1001 }

    private var cleaner: ICacheCleaner? = null
    private var isBound = false
    private lateinit var clearButton: MaterialButton
    private lateinit var statusText: TextView
    private lateinit var detailText: TextView

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    statusText.text = getString(R.string.status_connecting)
                    bindCleaner()
                } else {
                    statusText.text = getString(R.string.status_permission_denied)
                    Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                }
            }
        }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        statusText.text = getString(R.string.status_shizuku_ready)
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        cleaner = null
        isBound = false
        statusText.text = getString(R.string.status_shizuku_stopped)
        clearButton.isEnabled = true
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            cleaner = ICacheCleaner.Stub.asInterface(service)
            isBound = cleaner != null
            statusText.text = if (isBound) getString(R.string.status_ready)
                              else getString(R.string.status_connect_failed)
            clearButton.isEnabled = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            cleaner = null
            isBound = false
            statusText.text = getString(R.string.status_disconnected)
            clearButton.isEnabled = true
        }
    }

    private val serviceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, CacheCleanerService::class.java.name))
            .daemon(false)
            .processNameSuffix("cache_cleaner")
            .debuggable(false)
            .version(1)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clearButton = findViewById(R.id.btnClear)
        statusText = findViewById(R.id.txtStatus)
        detailText = findViewById(R.id.txtDetail)

        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)

        clearButton.setOnClickListener { onClearPressed() }

        statusText.text = if (Shizuku.pingBinder()) getString(R.string.status_shizuku_ready)
                          else getString(R.string.status_shizuku_stopped)
    }

    private fun onClearPressed() {
        if (!Shizuku.pingBinder()) {
            statusText.text = getString(R.string.status_shizuku_stopped)
            Toast.makeText(this, R.string.start_shizuku_first, Toast.LENGTH_LONG).show()
            return
        }

        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE)
            return
        }

        if (!isBound || cleaner == null) {
            clearButton.isEnabled = false
            statusText.text = getString(R.string.status_connecting)
            bindCleaner()
            return
        }

        clearButton.isEnabled = false
        statusText.text = getString(R.string.status_cleaning)
        detailText.text = getString(R.string.cleaning_detail)

        Thread {
            val result = try {
                cleaner?.clearAllCaches() ?: "ERROR\nService unavailable"
            } catch (e: Exception) {
                "ERROR\n${e.message ?: "Unknown error"}"
            }
            runOnUiThread {
                clearButton.isEnabled = true
                if (result.startsWith("SUCCESS")) {
                    statusText.text = getString(R.string.status_complete)
                    detailText.text = getString(R.string.clean_success_detail)
                    Toast.makeText(this, R.string.clean_complete, Toast.LENGTH_LONG).show()
                } else {
                    statusText.text = getString(R.string.status_failed)
                    detailText.text = result.removePrefix("ERROR").trim().ifBlank {
                        getString(R.string.unknown_error)
                    }
                }
            }
        }.start()
    }

    private fun bindCleaner() {
        if (isBound) return
        try {
            Shizuku.bindUserService(serviceArgs, connection)
        } catch (e: Exception) {
            clearButton.isEnabled = true
            statusText.text = getString(R.string.status_connect_failed)
            detailText.text = e.message ?: getString(R.string.unknown_error)
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        if (isBound) {
            try { Shizuku.unbindUserService(serviceArgs, connection, true) } catch (_: Exception) { }
        }
        super.onDestroy()
    }
}
