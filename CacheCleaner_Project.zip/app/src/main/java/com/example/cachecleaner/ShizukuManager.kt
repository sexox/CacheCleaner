
package com.example.cachecleaner

import android.content.ComponentName
import android.os.IBinder
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

object ShizukuManager {
    private var iService: ICacheCleaner? = null

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName("com.example.cachecleaner", CacheCleanerService::class.java.name)
    ).daemon(false).processNameSuffix("cleaner_service")

    fun isShizukuAvailable(): Boolean = Shizuku.pingBinder()
    
    fun hasPermission(): Boolean = 
        if (isShizukuAvailable()) Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED else false

    suspend fun connectService(): Boolean {
        if (!hasPermission()) return false
        if (iService != null && iService!!.asBinder().isBinderAlive) return true

        return withTimeoutOrNull(5000) {
            suspendCancellableCoroutine { cont ->
                val connection = object : Shizuku.UserServiceConnection {
                    override fun onServiceConnected(componentName: ComponentName, binder: IBinder) {
                        iService = ICacheCleaner.Stub.asInterface(binder)
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onServiceDisconnected(componentName: ComponentName) {
                        iService = null
                    }

                    override fun onBindingDied(componentName: ComponentName) {
                        iService = null
                        if (cont.isActive) cont.resume(false)
                    }

                    override fun onNullBinding(componentName: ComponentName) {
                        if (cont.isActive) cont.resume(false)
                    }
                }
                try {
                    Shizuku.bindUserService(userServiceArgs, connection)
                    cont.invokeOnCancellation {
                        Shizuku.unbindUserService(userServiceArgs, connection, true)
                    }
                } catch (e: Exception) {
                    if (cont.isActive) cont.resume(false)
                }
            }
        } ?: false // Timeout handled here
    }

    fun clearAppCache(packageName: String): Boolean {
        return try {
            iService?.clearCache(packageName) ?: false
        } catch (e: Exception) {
            false
        }
    }
}
